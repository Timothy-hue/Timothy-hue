<html>
<head></head><body>
<hr><hr>

<font size="6">
<?php
$servername = "localhost"; // Change if different
$username = "timmydb";
$password = "timmy254@";
$dbname = "timmybot";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$name = $_POST["name"];
$emailid = $_POST["emailid"];
$idno = $_POST["idno"];
$dob = $_POST["dob"];
$address = $_POST["address"];
$county = $_POST["county"];
$mobileno= $_POST["mobileno"];
$user = $_POST["user"];
$pass = $_POST["pass"];

$conn=new mysqli("localhost","root","","timmybot");

$stmt=$conn->prepare("insert into user (name,emailid,idno,dob,address,county,mobileno,user,password) value(?,?,?,?,?,?,?,?,?) ");
$stmt->bind_param("sssssssss", $name,$emailid,$idno,$dob,$address,$county,$mobileno,$user,$pass);
$stmt->execute();
$stmt->close();
?>
<script>
alert("Registration Successfull........");
</script>
<?php
include("userlogin.php")
?>

<hr><hr>
</font>
</body>
</html>