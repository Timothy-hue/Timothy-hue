
<?php
if (isset($_GET['token'])) {
    $token = $_GET['token'];

    // Verify the token and check if it hasn't expired
    $conn = new mysqli('localhost', 'timmydb', 'timmy254@', 'timmybot');
    $stmt = $conn->prepare("SELECT emailid FROM password_reset WHERE token=? AND expire_time > NOW()");
    $stmt->bind_param('s', $token);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        // Token is valid, show the reset form
        ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>reset</title>
    <link rel="stylesheet" href="login.css">

</head>
<body>
    <style>
*{
    margin: 0%;
    padding: 0%;
}
body{
    height: 100vh;
    display: grid;
    place-content: center;
    background-image: url('../idea/images/img.jpg');
    background-size:cover;
    background-repeat: no-repeat;
}
.container{
    border-top: 30px solid #04aa6d;
    border-right:4px solid #04aa6d;
    border-bottom :30px solid #04aa6d;
    border-left:4px solid #04aa6d;
    height: 480px;
    width: 390px;
    box-sizing: border-box;
    padding: 15px;
    background-color: rgb(221, 205, 205);
}
.header{
    text-align: center;
    margin-bottom: 20px;
    border-bottom: 4px solid #04aa6d;
}
h1{
   color: rgb(48, 15, 196);
    margin-bottom: 1px;
}
p{
    margin-bottom: 4px;
}
.inpu-field{
    display: flex;
    flex-direction: column;
}
.form-group{
    font-size: larger;
    text-shadow: #04aa6d;
        text-align: center;
        color: rgb(205, 0, 62);
}
input[type=password],input[type=email]{
margin:8px 0 15px 0;
font-size: 13px;
padding-left: 10px;
width: 330px;
height: 40px;
outline: none;
border: 1px solid #04aa6d;
}
input:hover{
    border: 2px solid yellow;
}
label{
    font-size: 20px;
}
.button{
    margin: 10px 0;
    width: 342px;
    height: 40px;
    font-size: 15px;
    border: none;
    cursor: pointer;
    background-color: purple;
    color: red;
}
.button:hover{
    background-color: gold;
}
.text-box{
    display: flex;
    flex-direction: column;
}
</style>
    <div class="container">
        
    <form action="updatepass.php" method="post">
            <div class="header">
                <h1>PASSWORD RESET</h1>
                <p>Please Set a Strong Password.</p>

            </div><br><br>
            <div class="input-field">
            <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
                <label><b>Enter Your New Password:</b></label><br><br>
                <input type="password" id="password" placeholder="Enter strong Password" name="password" required><br><br>
               <input  class="button"  type="submit" value="Submit" />
                </div>
                       </form>
    </div>
    
</body>
</html>
    <?php
    } else {
        echo "Invalid or expired token.";
    }

    $stmt->close();
    $conn->close();
} else {
    echo "No token provided.";
}
?>

