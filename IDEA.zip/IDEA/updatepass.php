
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $token = $_POST['token'];
    $new_password = password_hash($_POST['password'], PASSWORD_BCRYPT);

    // Database connection
    $conn = new mysqli('localhost', 'timmydb', 'timmy254@', 'timmybot');

    // Check if the token is valid
    $stmt = $conn->prepare("SELECT email FROM password_reset WHERE token=? AND expire_time > NOW()");
    $stmt->bind_param('s', $token);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        // Get the email associated with the token
        $stmt->bind_result($emailid);
        $stmt->fetch();

        // Update the user's password
        $stmt = $conn->prepare("UPDATE user SET password=? WHERE emailid=?");
        $stmt->bind_param('ss', $new_password, $emailid);
        $stmt->execute();

        // Delete the token so it can't be reused
        $stmt = $conn->prepare("DELETE FROM password_reset WHERE token=?");
        $stmt->bind_param('s', $token);
        $stmt->execute();

        echo "Your password has been reset successfully.";
    } else {
        echo "Invalid or expired token.";
    }

    $stmt->close();
    $conn->close();
}
?>