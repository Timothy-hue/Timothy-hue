
<?php
 session_start();
?>


<html>
<head>
</head>
<body>




<?php
$conn=new mysqli("localhost","root","","timmybot");
$emailid = $_POST["emailid"];
$pass = $_POST["pass"];
$result = $conn->query("SELECT * FROM user where user= '$emailid' and password= '$pass'");
	if ($result->num_rows > 0)
	{
	 
	
	             $_SESSION["user"] = $emailid; 
				header("Location:dahboard.php"); 
include("userlogin.php");
		 	}		
else
{
?> <script> alert("Invalid user name or password");</script>
<?php include("userlogin.php"); }?> 


</body>
</html>
  
  