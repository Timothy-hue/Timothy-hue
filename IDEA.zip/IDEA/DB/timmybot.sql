-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 14, 2024 at 08:25 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `timmybot`
--

-- --------------------------------------------------------

--
-- Table structure for table `password_reset`
--

CREATE TABLE `password_reset` (
  `id` int(11) NOT NULL,
  `emailid` varchar(256) NOT NULL,
  `token` varchar(100) NOT NULL,
  `expire_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `password_reset`
--

INSERT INTO `password_reset` (`id`, `emailid`, `token`, `expire_time`) VALUES
(11, 'timmytimo360@gmail.com', '950c7273db0987539a237afcb9106bed21fb691d479ae3a6c9bd56770f05c7fd8ee289b0aca44d4349c5e0eb7c0aa1769e6d', '2024-08-06 12:02:49'),
(12, 'timmytimo360@gmail.com', 'f94f32af2ac47e58739cce8775dcca5afa4e4a7613ee620bb4e11c1927bcb1e49bb8e104eaaaba4824618910da049a1a274b', '2024-08-13 15:55:58'),
(13, 'timothywafula488@gmail.com', '6a20028a0ad8eafb00fa4dc12bb781a11f755f8d0f72ea0b9234bb8bb732641e847f6b92b73cb5b209131bdb1afb99c35bc6', '2024-08-13 15:59:06'),
(14, 'timothywafula488@gmail.com', 'c69f93b7e1265ff8f122a21de9829d4a95d5b688af230d8b44cac41a407d27599da3e5fb9de72271b27b9d78e67096571ee5', '2024-08-13 16:22:42');

-- --------------------------------------------------------

--
-- Table structure for table `plogin`
--

CREATE TABLE `plogin` (
  `id` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `plogin`
--

INSERT INTO `plogin` (`id`, `username`, `password`) VALUES
(1, 'timmo', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `emailid` varchar(80) NOT NULL,
  `idno` varchar(30) NOT NULL,
  `dob` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `county` varchar(50) NOT NULL,
  `mobileno` varchar(20) NOT NULL,
  `user` varchar(20) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `emailid`, `idno`, `dob`, `address`, `county`, `mobileno`, `user`, `password`) VALUES
(24, 'timothy', 'timmytimo360@gmail.com', '38452935', '1202-02-02', 'kipkaren', 'kakamega', '0759924977', 'timmydb', '123'),
(25, 'timmy', 'timmytimo360@gmail.com', '38452935', '2025-12-25', 'eld', 'kakamega', '0759924977', 'timmy', '123'),
(26, 'timothy', 'timmytimo360@gmail.com', '38452935', '2024-04-05', 'kipkaren', 'kakamega', '0759924977', 'timo', '1234'),
(27, 'timothy', 'timmytimo360@gmail.com', '38452935', '2024-04-05', 'kipkaren', 'kakamega', '0759924977', 'timo', '1234'),
(28, 'timmy', 'timothywafula488@gmail.com', '38452935', '2024-08-05', 'eld', 'kakamega', '0759924977', 'timmo', '123'),
(29, 'timmy', 'timothywafula488@gmail.com', '38452935', '2025-02-05', 'kipkaren', 'kakamega', '0759924977', 'TMO', '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `password_reset`
--
ALTER TABLE `password_reset`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `plogin`
--
ALTER TABLE `plogin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `password_reset`
--
ALTER TABLE `password_reset`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `plogin`
--
ALTER TABLE `plogin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
