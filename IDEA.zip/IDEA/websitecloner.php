<?php

class WebsiteCloner {
    private $base_url;
    private $parsed_base_url;
    private $download_path;
    private $visited;

    public function __construct($base_url, $download_path = 'cloned_site') {
        $this->base_url = $base_url;
        $this->parsed_base_url = parse_url($base_url);
        $this->download_path = $download_path;
        $this->visited = [];
    }

    public function clone() {
        $this->fetchPage($this->base_url);
    }

    private function fetchPage($url) {
        if (in_array($url, $this->visited)) {
            return;
        }
        $this->visited[] = $url;

        $headers = get_headers($url, 1);
        if (!$headers || strpos($headers[0], '200') === false) {
            echo "Failed to fetch $url\n";
            return;
        }

        $contentType = isset($headers['Content-Type']) ? $headers['Content-Type'] : '';
        $content = file_get_contents($url);

        if (strpos($contentType, 'text/html') !== false) {
            $this->saveHtml($content, $url);
        } else {
            $this->saveBinary($content, $url);
        }
    }

    private function saveHtml($html_content, $url) {
        $dom = new DOMDocument();
        @$dom->loadHTML($html_content);
        $this->processResources($dom, $url);

        $relative_path = $this->getRelativePath($url);
        $file_path = $this->download_path . '/' . $relative_path;

        if (!file_exists(dirname($file_path))) {
            mkdir(dirname($file_path), 0777, true);
        }

        file_put_contents($file_path, $dom->saveHTML());

        // Find and process all linked pages
        foreach ($dom->getElementsByTagName('a') as $link) {
            $href = $link->getAttribute('href');
            $absolute_url = $this->urlJoin($url, $href);
            if ($this->isSameDomain($absolute_url)) {
                $this->fetchPage($absolute_url);
            }
        }
    }

    private function processResources($dom, $page_url) {
        $tagsAttrs = [
            'img' => 'src',
            'script' => 'src',
            'link' => 'href'
        ];

        foreach ($tagsAttrs as $tag => $attr) {
            $elements = $dom->getElementsByTagName($tag);
            foreach ($elements as $element) {
                $resource_url = $element->getAttribute($attr);
                if (!$resource_url) {
                    continue;
                }
                $absolute_url = $this->urlJoin($page_url, $resource_url);
                if (!$this->isSameDomain($absolute_url)) {
                    continue;
                }
                $this->fetchPage($absolute_url);
                $resource_path = $this->getRelativePath($absolute_url);
                $element->setAttribute($attr, $resource_path);
            }
        }
    }

    private function saveBinary($content, $url) {
        $relative_path = $this->getRelativePath($url);
        $file_path = $this->download_path . '/' . $relative_path;

        if (!file_exists(dirname($file_path))) {
            mkdir(dirname($file_path), 0777, true);
        }

        file_put_contents($file_path, $content);
    }

    private function getRelativePath($url) {
        $parsed_url = parse_url($url);
        $path = isset($parsed_url['path']) ? $parsed_url['path'] : '';
        if (substr($path, -1) === '/') {
            $path .= 'index.html';
        } elseif (!pathinfo($path, PATHINFO_EXTENSION)) {
            $path .= '.html';
        }
        return $parsed_url['host'] . $path;
    }

    private function urlJoin($base, $relative) {
        if (parse_url($relative, PHP_URL_SCHEME) != '') {
            return $relative;
        }
        if ($relative[0] == '/') {
            return $this->parsed_base_url['scheme'] . '://' . $this->parsed_base_url['host'] . $relative;
        }
        $path = rtrim(dirname($this->parsed_base_url['path']), '/') . '/';
        return $this->parsed_base_url['scheme'] . '://' . $this->parsed_base_url['host'] . $path . $relative;
    }

    private function isSameDomain($url) {
        return parse_url($url, PHP_URL_HOST) === $this->parsed_base_url['host'];
    }
}

// Usage
$base_website_url = 'https://example.com';  // Replace with the target website URL
$cloner = new WebsiteCloner($base_website_url);
$cloner->clone();
echo "Website cloning completed.\n";

?>
