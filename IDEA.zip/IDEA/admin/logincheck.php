

<html>
<head>
</head>
<body>




<?php
$conn=new mysqli("localhost","root","","timmybot");
$emailid = $_POST["emailid"];
$pass = $_POST["pass"];
$result = $conn->query("SELECT * FROM tlogin where username= '$emailid' and password= '$pass'");
	if ($result->num_rows > 0)
	{
	 
	
	             $_SESSION["user"] = $emailid; 
				header("Location:dahboard.php"); 
include("login.php");
		 	}		
else
{
?> <script> alert("Invalid Credentials");</script>
<?php include("login.php"); }?> 


</body>
</html>
  
  