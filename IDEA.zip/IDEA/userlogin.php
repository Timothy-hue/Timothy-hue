
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login</title>
    <link rel="stylesheet" href="admin/login.css">

</head>
<body>
    <div class="container">
        
       <form action="usercheck.php" method="post"  >
            <div class="header">
                <h1>Login</h1>
                <p>Please fill in the Correct Details To Login.</p>

            </div><br><br>
            <div class="input-field">
                <label><b>User Name:</b></label>
                <input class="form-control" type="user" name="emailid" placeholder="Enter User Name" required>
                <label><b>Password:</b></label><br><br>
                <input class="form-control" type="password" name="pass" placeholder="Enter Password" required>
                <input class="button" type="submit" value="Submit" >
                </div>
                <div class="form-group m-b-0">
                    <div class="col-sm-12 text-center">
                        <a href="forgotenpass.html">
                            Forgoten password
<br>
<br>
                            <a href="signup.html">
                                Create account
    
            </div>
        </form>
    </div>
    
</body>
</html>