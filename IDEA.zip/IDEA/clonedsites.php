
<?php

class WebsiteCloner {
    private $base_url;
    private $parsed_base_url;
    private $download_path;
    private $visited;

    public function __construct($base_url) {
        $this->base_url = $base_url;
        $this->parsed_base_url = parse_url($base_url);
        $this->download_path = 'cloned_sites/' . $this->parsed_base_url['host'];

        // Create the directory if it doesn't exist
        if (!file_exists($this->download_path)) {
            mkdir($this->download_path, 0777, true);
        }

        $this->visited = [];
    }

    public function clone() {
        $this->fetchPage($this->base_url);
    }

    // Rest of the class implementation...
}


