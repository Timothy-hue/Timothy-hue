<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $emailid = $_POST['emailid'];

    // Database connection (Replace with your database credentials)
    $conn = new mysqli('localhost', 'timmydb', 'timmy254@', 'timmybot');

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Check if the email exists in the database
    $sql = "SELECT id FROM user WHERE emailid=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('s', $emailid);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        // Generate a unique token
        $token = bin2hex(random_bytes(50));

        // Store the token in the database with an expiration time (e.g., 1 hour)
        $expire_time = date("Y-m-d H:i:s", strtotime('+2 hour'));
        $stmt = $conn->prepare("INSERT INTO password_reset (emailid, token, expire_time) VALUES (?, ?, ?)");
        $stmt->bind_param('sss', $emailid, $token, $expire_time);
        $stmt->execute();

        // Send the reset link to the user's email
        $reset_link = "http://timmytimo360@.com/passwordreset.php?token=" . $token;
        $subject = "Password Reset Request";
        $message = "Click on this link to reset your password: " . $reset_link;
        $headers = "From: no-reply@timmytimo360@.com";

        mail($emailid, $subject, $message, $headers);

        echo "A password reset link has been sent to your email.";
    } else {
        echo "No account found with that email address.";
    }

    $stmt->close();
    $conn->close();
}
?>
